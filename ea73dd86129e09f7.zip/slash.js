module.exports = async (client) => {
  let array = [

    {
      name: "give",
      description: "قم باعطاء.",
      
    },
 



 
  ];
  await client.application.commands.set(array);
}